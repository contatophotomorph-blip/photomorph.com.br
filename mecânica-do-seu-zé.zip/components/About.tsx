import React from 'react';

const About: React.FC = () => {
  return (
    <section id="sobre" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-stone-50 rounded-2xl shadow-xl overflow-hidden flex flex-col md:flex-row">
            <div className="md:w-1/2 h-64 md:h-auto relative">
                <img 
                    src="https://picsum.photos/800/800" 
                    alt="Mecânico trabalhando" 
                    className="w-full h-full object-cover"
                />
            </div>
            <div className="md:w-1/2 p-8 md:p-12 flex flex-col justify-center">
                <div className="uppercase tracking-wide text-sm text-brown-600 font-semibold mb-2">Nossa História</div>
                <h2 className="text-3xl font-bold text-brown-900 mb-4">Sobre a Mecânica</h2>
                <p className="text-stone-600 leading-relaxed mb-6">
                    Localizada na rua Bonfim, número 899, a Mecânica Do Seu Zé oferece manutenção completa, reparos e peças de alta qualidade.
                </p>
                <p className="text-stone-600 leading-relaxed">
                    Trabalhamos com dedicação e honestidade para garantir o melhor para seu veículo. Aqui, você não é apenas um cliente, é um amigo da casa.
                </p>
            </div>
        </div>
      </div>
    </section>
  );
};

export default About;