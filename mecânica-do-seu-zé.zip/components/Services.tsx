import React from 'react';
import { ServiceItem } from '../types';

const serviceList: ServiceItem[] = [
  { 
    title: 'Peças Originais', 
    description: 'Trabalhamos com peças originais e paralelas de primeira linha.',
    icon: '⚙️' 
  },
  { 
    title: 'Motores', 
    description: 'Retífica completa, ajustes e troca de óleo especializada.',
    icon: '🔧' 
  },
  { 
    title: 'Freios', 
    description: 'Manutenção de pastilhas, discos e sistema ABS.',
    icon: '🛑' 
  },
  { 
    title: 'Suspensão', 
    description: 'Amortecedores, molas e alinhamento de direção.',
    icon: '🚙' 
  },
];

const Services: React.FC = () => {
  return (
    <section id="pecas" className="py-16 bg-brown-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-brown-900 mb-4">Nossas Peças e Serviços</h2>
            <div className="w-24 h-1 bg-brown-400 mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {serviceList.map((item, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-md hover:shadow-xl transition-shadow border-t-4 border-brown-600 group">
              <div className="text-4xl mb-4 group-hover:scale-110 transition-transform duration-300">{item.icon}</div>
              <h3 className="text-xl font-bold text-brown-800 mb-2">{item.title}</h3>
              <p className="text-stone-600 text-sm">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;