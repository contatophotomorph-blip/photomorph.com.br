import React from 'react';

const Hero: React.FC = () => {
  return (
    <section id="inicio" className="relative bg-brown-900 text-white py-20 md:py-32 overflow-hidden">
      <div className="absolute inset-0 opacity-40">
        {/* Placeholder image for a car workshop */}
        <img 
            src="https://picsum.photos/1600/900?grayscale" 
            alt="Oficina Mecânica" 
            className="w-full h-full object-cover"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-brown-900 via-brown-900/60 to-transparent"></div>
      
      <div className="relative container mx-auto px-4 text-center">
        <h2 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg">
          Confiança e Qualidade <br/> <span className="text-brown-400">Há Anos</span>
        </h2>
        <p className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl mx-auto leading-relaxed">
            Especialistas em cuidar do seu veículo com honestidade. Manutenção, reparos e peças originais com o atendimento que você conhece.
        </p>
        <div className="flex flex-col md:flex-row justify-center gap-4">
            <a href="#contato" className="bg-brown-400 hover:bg-brown-500 text-brown-900 font-bold py-3 px-8 rounded-full transition-transform transform hover:scale-105 shadow-lg">
              Agendar Visita
            </a>
            <a href="#chat" className="bg-transparent border-2 border-white hover:bg-white hover:text-brown-900 text-white font-bold py-3 px-8 rounded-full transition-all">
              Falar com o Zé (IA)
            </a>
        </div>
      </div>
    </section>
  );
};

export default Hero;