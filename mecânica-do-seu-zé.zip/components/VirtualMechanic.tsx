import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { sendMessageToMechanic } from '../services/geminiService';

const VirtualMechanic: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Opa, meu patrão! Seu Zé na escuta. O que o possante tá aprontando hoje?', timestamp: new Date() }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      role: 'user',
      text: inputValue,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    const responseText = await sendMessageToMechanic(inputValue);

    const modelMessage: ChatMessage = {
      role: 'model',
      text: responseText,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, modelMessage]);
    setIsLoading(false);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <section id="chat" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden">
          <div className="bg-brown-800 p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-brown-400 flex items-center justify-center text-brown-900 font-bold text-2xl border-2 border-white shadow-sm">
                Z
                </div>
                <div>
                    <h2 className="text-white font-bold text-lg leading-tight">Consultor Virtual do Zé</h2>
                    <p className="text-brown-300 text-xs">IA Treinada pelo Seu Zé</p>
                </div>
            </div>
            <div className="flex items-center gap-2 bg-brown-900/50 px-3 py-1 rounded-full border border-brown-700">
                <span className="relative flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                <span className="text-xs text-green-400 font-medium">Online</span>
            </div>
          </div>

          <div className="h-96 overflow-y-auto p-6 bg-stone-100 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] p-4 rounded-2xl text-sm leading-relaxed shadow-sm ${
                    msg.role === 'user'
                      ? 'bg-brown-600 text-white rounded-tr-none'
                      : 'bg-white text-stone-800 border border-stone-200 rounded-tl-none'
                  }`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white text-stone-500 p-4 rounded-2xl rounded-tl-none border border-stone-200 text-xs italic flex items-center gap-2">
                  <svg className="animate-spin h-4 w-4 text-brown-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Seu Zé está analisando...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 bg-white border-t border-stone-200">
            <div className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyPress}
                placeholder="Descreva o problema (ex: carro falhando quando acelera...)"
                className="flex-1 p-3 border border-stone-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-brown-500 focus:border-transparent text-stone-700 placeholder-stone-400 transition-all"
                disabled={isLoading}
                autoFocus
              />
              <button
                onClick={handleSendMessage}
                disabled={isLoading || !inputValue.trim()}
                className="bg-brown-600 hover:bg-brown-700 disabled:bg-stone-300 disabled:cursor-not-allowed text-white font-bold py-2 px-6 rounded-xl transition-colors shadow-sm"
              >
                Enviar
              </button>
            </div>
            <p className="text-[10px] text-stone-400 mt-2 text-center">
                O Zé Virtual pode cometer erros. Traga seu carro na oficina para ter certeza.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default VirtualMechanic;