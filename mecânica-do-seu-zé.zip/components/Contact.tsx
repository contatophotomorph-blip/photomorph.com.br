import React from 'react';

const Contact: React.FC = () => {
  return (
    <section id="contato" className="py-16 bg-brown-900 text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
                <h2 className="text-3xl font-bold mb-6">Entre em Contato</h2>
                <p className="mb-8 text-brown-200">
                    Estamos prontos para atender você. Venha nos visitar ou ligue para agendar um horário.
                </p>
                
                <div className="space-y-6">
                    <div className="flex items-start gap-4">
                        <div className="bg-brown-700 p-3 rounded-lg">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-brown-400">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
                            </svg>
                        </div>
                        <div>
                            <h4 className="font-bold text-lg">Endereço</h4>
                            <p className="text-brown-200">Rua Bonfim, nº 899</p>
                            <p className="text-brown-300 text-sm">Centro - Sua Cidade/UF</p>
                        </div>
                    </div>

                    <div className="flex items-start gap-4">
                        <div className="bg-brown-700 p-3 rounded-lg">
                            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 text-brown-400">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6.75c0 8.284 6.716 15 15 15h2.25a2.25 2.25 0 002.25-2.25v-1.372c0-.516-.351-.966-.852-1.091l-4.423-1.106c-.44-.11-.902.055-1.173.417l-.97 1.293c-.282.376-.769.542-1.21.38a12.035 12.035 0 01-7.143-7.143c-.162-.441.004-.928.38-1.21l1.293-.97c.363-.271.527-.734.417-1.173L6.963 3.102a1.125 1.125 0 00-1.091-.852H4.5A2.25 2.25 0 002.25 4.5v2.25z" />
                            </svg>
                        </div>
                        <div>
                            <h4 className="font-bold text-lg">Telefone</h4>
                            <p className="text-brown-200">99 99999999</p>
                            <p className="text-brown-300 text-sm">Segunda a Sexta, 08h às 18h</p>
                        </div>
                    </div>
                </div>
            </div>

            <div className="bg-brown-800 p-2 rounded-xl h-64 md:h-80 shadow-inner">
                 {/* Map Placeholder */}
                <div className="w-full h-full bg-brown-700 rounded-lg flex items-center justify-center relative overflow-hidden group">
                     <img 
                        src="https://picsum.photos/600/400?blur=2" 
                        alt="Mapa da Localização" 
                        className="absolute inset-0 w-full h-full object-cover opacity-50 group-hover:opacity-40 transition-opacity"
                    />
                    <div className="relative z-10 text-center p-4">
                        <p className="font-bold text-xl mb-2">Mapa</p>
                        <button className="bg-white text-brown-900 px-4 py-2 rounded-full text-sm font-bold hover:bg-brown-100 transition-colors">
                            Ver no Google Maps
                        </button>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;