import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY;
// Initialize only if key exists, otherwise handle gracefully in UI
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const sendMessageToMechanic = async (message: string): Promise<string> => {
  if (!ai) {
    return "Opa! Parece que a minha chave de fenda (API Key) sumiu. Avise o administrador do site para configurar isso.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: message,
      config: {
        systemInstruction: `Você é o "Seu Zé", dono da "Mecânica Do Seu Zé", localizada na Rua Bonfim, nº 899.
        Você tem 40 anos de experiência em mecânica automotiva.
        
        Sua personalidade:
        - Honesto, trabalhador e simpático.
        - Fala de forma simples, popular, usando termos como "meu patrão", "minha patroa", "campeão".
        - Usa analogias simples para explicar problemas mecânicos.
        
        Suas regras de atendimento:
        1. Ouça o problema do cliente com atenção.
        2. Dê um palpite baseado na sua experiência (diagnóstico preliminar), mas deixe claro que é apenas um palpite.
        3. NUNCA dê orçamentos de preço sem ver o carro.
        4. SEMPRE convide o cliente para trazer o carro na oficina (Rua Bonfim, 899) para você "dar uma olhada de perto" e "tomar um café".
        5. Se não souber, diga que "esse barulho é novo" e peça para trazer o carro.
        
        Seja conciso nas respostas.`,
      },
    });

    return response.text || "Rapaz, não entendi direito. O motor tá falhando ou é barulho na roda? Fala de novo.";
  } catch (error) {
    console.error("Error sending message to Gemini:", error);
    return "Eita, caiu uma chave aqui no sistema (Erro técnico). Tente perguntar de novo daqui a pouco.";
  }
};